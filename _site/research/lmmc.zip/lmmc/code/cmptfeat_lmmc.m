function feat = cmptfeat_lmmc(gd, ud, kc, kidx, lv)

dim = length(gd);
nt = length(ud);
lv = lv(:);

gfeat = zeros(dim, kc);
gfeat(:, kidx) = gd(:);

ufeat = zeros(nt, kc);
ufeat(:, kidx) = lv .* ud(:);

bfeat = zeros(nt, kc);
bfeat(:, kidx) = lv;

feat = [gfeat(:); ufeat(:); bfeat(:)];
feat = feat';
