function results = eval_lmmc(w, auxdata)

global data udata;
[ni, dim] = size(data);
nt = size(udata, 2);
kc = auxdata.kc;

ww = parsew_lmmc(w, dim, nt, kc);

gscores = data * ww.gw;
[uscores, latvar] = infer_lmmc(ww);
scores = gscores + uscores;

lsize = auxdata.clsrbal * (ni / kc);
usize = (2 - auxdata.clsrbal) * (ni / kc);
labels = assign_lpa(scores, lsize, usize);

results.labels = labels;
results.scores = scores;
results.latvar = latvar;
