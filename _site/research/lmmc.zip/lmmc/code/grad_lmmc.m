function [fval, grad] = grad_lmmc(w, auxdata)

global data udata perf;
[ni, dim] = size(data);
nt = size(udata, 2);
kc = auxdata.kc;

ww = parsew_lmmc(w, dim, nt, kc);

gscores = data * ww.gw;
[uscores, latvar] = infer_lmmc(ww);
scores = gscores + uscores;

lsize = auxdata.clsrbal * (ni / kc);
% usize = 1.1 * (ni / kc);
usize = (2 - auxdata.clsrbal) * (ni / kc);
labels = assign_lpa(scores, lsize, usize);

% track performance
perf.iter = perf.iter + 1;
[perf.pa(perf.iter), perf.pp(perf.iter)] = measure_purity(perf.labeltr, labels);
perf.nmi(perf.iter) = measure_nmi(perf.labeltr, labels);
perf.ri(perf.iter) = measure_randindex(perf.labeltr, labels);
save(auxdata.modelfile, 'perf', '-append');

% most violated constraints
fval = 0;
grad = zeros(1, length(w));

for i = 1:ni
    p = labels(i);
    featp = cmptfeat_lmmc(data(i, :), udata(i, :), kc, p, latvar(i, p, :));
    
    for n = 1:kc
        if n == p, continue; end
        xip = 1 + scores(i, n) - scores(i, p);
        if xip < 0, continue; end
        
        fval = fval + xip;
        featn = cmptfeat_lmmc(data(i, :), udata(i, :), kc, n, latvar(i, n, :));
        grad = grad + featn - featp;
    end
end

fval = fval / kc;
grad = grad / kc;
