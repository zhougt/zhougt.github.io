function [uscores, latvar] = infer_lmmc(ww)

global udata;

[ni, nt] = size(udata);
kc = size(ww.uw, 2);

latvar = zeros(ni, kc, nt);
uscores = zeros(ni, kc);

for i = 1:ni
    for k = 1:kc
        pot = ww.uw(:, k) .* udata(i, :)' + ww.bw(:, k);
        lv = zeros(nt, 1);
        lv(pot > 0) = 1;
        latvar(i, k, :) = lv;
        uscores(i, k) = mean(max(pot, 0));
    end
end
