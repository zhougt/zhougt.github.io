function main_lmmc(conf)

clearvars -global;
global data udata perf;
perf.iter = 0;

switch conf.data
    case 0 % trecvid: tag detection scores
        load([conf.datapath, 'trecvid11_classlabels.mat'], 'labeltr');
        load([conf.datapath, 'trecvid11_tagsc.mat'], 'tagsctr');
        data = zeros(size(tagsctr, 1), 0);
        udata = single(tagsctr);
        clear tagsctr;
end
data = [data, ones(size(data, 1), 1)];
udata = zscore(udata, 0, 1);
[~, perf.labeltr] = max(labeltr, [], 2);

auxdata.kc = conf.kc;
auxdata.clsrbal = conf.clsrbal;

% model file
respath = [conf.datapath, 'results/lmmc/'];
if ~exist(respath, 'dir'), mkdir(respath); end
modelname = ['lmmc_', num2str(conf.data), '_', num2str(conf.clsrbal), ...
    '_', num2str(conf.kc), '_', num2str(conf.alpha)];

auxdata.modelfile = [respath, modelname, '.mat'];
save(auxdata.modelfile, 'perf');
auxdata.diaryfile = [respath, 'log/', modelname, '.log'];
if ~exist([respath, 'log/'], 'dir'), mkdir([respath, 'log/']); end
if exist(auxdata.diaryfile, 'file'), delete(auxdata.diaryfile); end
diary(auxdata.diaryfile);

nt = size(udata, 2);
gw = zeros(1, conf.kc); % global weight on each cluster
uw = ones(nt, conf.kc); % unary weight on each tag and each cluster
bw = zeros(nt, conf.kc); % bias term on unary weght
w0 = [gw(:)', uw(:)', bw(:)'];

% NRBM training
tic;
times.cpu = cputime;
lambda = conf.alpha;
[w, ~, ~, ~] = NRBM(w0, lambda, conf.nrbm, @grad_lmmc, auxdata);
times.cpu = cputime - times.cpu;
times.tic = toc;

results = eval_lmmc(w, auxdata);
save(auxdata.modelfile, 'w', 'conf', 'results', 'times', '-append');

