function ww = parsew_lmmc(w, dim, nt, kc)

start = 0;
len = dim * kc;
ww.gw = reshape(w(start + 1:start + len)', [dim, kc]);

start = start + len;
len = nt * kc;
ww.uw = reshape(w(start + 1:start + len)', [nt, kc]);

start = start + len;
len = nt * kc;
ww.bw = reshape(w(start + 1:start + len)', [nt, kc]);
