function run_lmmc(DataSets, ClsrBals, KCs, AlphaPows)

% Default parameters:
%   DataSets = 0;
%   ClsrBals = 0.9;
%   KCs = 15;
%   AlphaPows = -1;

addpath(genpath('toolbox/'));

conf.rootpath = pwd;
conf.rootpath(end - 3:end) = [];
conf.datapath = [conf.rootpath, 'data/'];
conf.nrbm = struct('lambda', 1, ... % regularization parameter
    'maxiter', 500, ... % max number of iteration
    'maxCP', 200, ... % max number of cutting plane
    'epsilon', 0.01, ... % stop criteria gap
    'fpositive', 0, ... % f is not a positive function
    'nonconvex', 1); % non-convex NRBM

for i = 1:length(DataSets)
    for j = 1:length(ClsrBals)
        for k = 1:length(KCs)
            for l = 1:length(AlphaPows)
                conf.data = DataSets(i);
                conf.clsrbal = ClsrBals(j);
                conf.kc = KCs(k);
                conf.alpha = 10 .^ AlphaPows(l);
                main_lmmc(conf);
            end
        end
    end
end
