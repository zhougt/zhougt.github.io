% clustering TRECVID'11 data with LMMC

run_lmmc(0, 0.9, 15, -1);
% run_lmmc(0, 0.9, 15, -2);
% run_lmmc(0, 0.9, 15, -3);
