cd lib

mex gmnp_mex.c gmnplib.c

mex libqp_splx_mex.c libqp_splx.c

cd ..
mex wsum_col.c
