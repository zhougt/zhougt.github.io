Non-convex Regularized Bundle Method (NRBM).

* standard regularization term use NRBM()
* more general regularization term use GNRBM()

http://webia.lip6.fr/~do/pmwiki/pmwiki.php/Main/Codes
