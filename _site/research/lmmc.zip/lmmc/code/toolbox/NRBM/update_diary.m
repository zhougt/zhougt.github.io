function update_diary()

	if(strcmp(get(0,'diary'),'on'))

		diary off;diary on;

	end


