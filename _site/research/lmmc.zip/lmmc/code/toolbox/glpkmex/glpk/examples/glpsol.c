/* glpsol.c */

#include <glpk.h>

int main(int argc, const char *argv[])
{     /* stand-alone LP/MIP solver */
      return glp_main(argc, argv);
}

/* eof */
