Data:
n x d matrix;
n - # of instances;
d - # of dimension;

Labels: 
1 - anomaly;
0 - normal instance;