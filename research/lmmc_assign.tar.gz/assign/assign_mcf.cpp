#include <lemon/list_graph.h>
#include <lemon/network_simplex.h>
#include <lemon/cost_scaling.h>
#include <lemon/capacity_scaling.h>
#include <lemon/core.h>

#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <limits>
#include <algorithm>
#include <mex.h>

using namespace std;
using namespace lemon;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]){
    
    // input parameters
    enum{
        COSTS_IN = 0, // input costs
        OPTS_IN, // options
    };
    
    if (nrhs <= COSTS_IN)
        mexErrMsgTxt("Not enough inputs!");
    
    double *costs = mxGetPr(prhs[COSTS_IN]);
    int n = mxGetM(prhs[COSTS_IN]);
    int k = mxGetN(prhs[COSTS_IN]);
    int fidx;
    
    // MCF solver
    int mcfSolver = 1;
    if (nrhs == OPTS_IN + 1){
        fidx = mxGetFieldNumber(prhs[OPTS_IN], "mcfSolver");
        if (fidx != -1){
            mcfSolver = (int) mxGetScalar(mxGetFieldByNumber(prhs[OPTS_IN], 0, fidx));
        }
    }
    typedef CapacityScaling<ListDigraph, int, float> MCFSolver;
    if (mcfSolver == 2){
        typedef CostScaling<ListDigraph, int, float> MCFSolver;
    }
    else if (mcfSolver == 3){
        typedef NetworkSimplex<ListDigraph, int, float> MCFSolver;
    }
    
    // percentage of flow
    double fRate = 1;
    if (nrhs == OPTS_IN + 1){
        fidx = mxGetFieldNumber(prhs[OPTS_IN], "fRate");
        if (fidx != -1){
            fRate = (double) mxGetScalar(mxGetFieldByNumber(prhs[OPTS_IN], 0, fidx));
        }
    }
    int nFlow = floor(double(n) * fRate + 0.5);
    
    // lsize & usize
    double lsizeRate = 0.9;
    double usizeRate = 1.1;
    if (nrhs == OPTS_IN + 1){
        fidx = mxGetFieldNumber(prhs[OPTS_IN], "lsizeRate");
        if (fidx != -1){
            lsizeRate = (double) mxGetScalar(mxGetFieldByNumber(prhs[OPTS_IN], 0, fidx));
        }
        fidx = mxGetFieldNumber(prhs[OPTS_IN], "usizeRate");
        if (fidx != -1){
            usizeRate = (double) mxGetScalar(mxGetFieldByNumber(prhs[OPTS_IN], 0, fidx));
        }
    }
    int lsize = floor(double(nFlow) * lsizeRate / double(k) + 0.5);
    int usize = floor(double(nFlow) * usizeRate / double(k) + 0.5);
    
    // mexPrintf("%g\n", double(nFlow));
    // mexPrintf("%g\n", double(lsizeRate));
    // mexPrintf("%g\n", double(usizeRate));
    // mexPrintf("%g\n", double(lsize));
    // mexPrintf("%g\n", double(usize));
    
    // make graph
    ListDigraph graph;
    ListDigraph::ArcMap<float> graphCosts(graph);
    ListDigraph::ArcMap<int> graphCaps(graph);
    ListDigraph::Node v, u;
    ListDigraph::Arc arc;
    
    // nodes: source & terminal
    ListDigraph::Node sNode = graph.addNode();
    ListDigraph::Node tNode = graph.addNode();
    ListDigraph::Node ttNode = graph.addNode();
    
    // nodes: data
    vector<ListDigraph::Node> dataNodes;
    for (int i = 0; i < n; i++){
        u = graph.addNode();
        dataNodes.push_back(u);
    }
    
    // nodes: cluster
    vector<ListDigraph::Node> clusterNodes;
    for (int j = 0; j < k; j++){
        v = graph.addNode();
        clusterNodes.push_back(v);
    }
    
    //arcs: source --> data
    vector<ListDigraph::Arc> sdArcs;
    for (int i = 0; i < n; i++){
        arc = graph.addArc(sNode, dataNodes[i]);
        graphCosts[arc] = 0;
        graphCaps[arc] = 1;
        sdArcs.push_back(arc);
    }
    
    // arcs: data --> cluster
    vector< vector<ListDigraph::Arc> > dcArcs;
    for (int i = 0; i < n; i++){
        vector<ListDigraph::Arc> tmp;
        for (int j = 0; j < k; j++){
            arc = graph.addArc(dataNodes[i], clusterNodes[j]);
            graphCosts[arc] = (float) costs[j * n + i];
            graphCaps[arc] = 1;
            tmp.push_back(arc);
        }
        dcArcs.push_back(tmp);
    }
    
    // arcs: cluster --> terminal
    vector<ListDigraph::Arc> ctArcs;
    for (int j = 0; j < k; j++){
        arc = graph.addArc(clusterNodes[j], tNode);
        graphCosts[arc] = 0;
        graphCaps[arc] = usize - lsize;
        ctArcs.push_back(arc);
    }
    
    // arcs: cluster --> final terminal
    vector<ListDigraph::Arc> cttArcs;
    for (int j = 0; j < k; j++){
        arc = graph.addArc(clusterNodes[j], ttNode);
        graphCosts[arc] = 0;
        graphCaps[arc] = lsize;
        cttArcs.push_back(arc);
    }
    
    // arcs: terminal --> final terminal
    arc = graph.addArc(tNode, ttNode);
    graphCosts[arc] = 0;
    graphCaps[arc] = nFlow - k * lsize;
    //ListDigraph::Arc tttArcs = arc;
    
    // min-cost flow
    MCFSolver solver(graph);
    solver.upperMap(graphCaps);
    solver.costMap(graphCosts);
    solver.stSupply(sNode, ttNode, nFlow);
    MCFSolver::ProblemType solution = solver.run();
    
    // parse results
    double totalCost = 0;
    double *dcFlow = new double[n * k];
    memset(dcFlow, 0, n * k * sizeof(double));
    
    //double *sdFlow = new double[n];
    //memset(sdFlow, 0, n * sizeof(double));
    //double *ctFlow = new double[k];
    //memset(ctFlow, 0, k * sizeof(double));
    //double *cttFlow = new double[k];
    //memset(cttFlow, 0, k * sizeof(double));
    //double tttFlow = 0;
    
    if (solution == MCFSolver::INFEASIBLE){
        mexPrintf("MCF solution is infeasible!\n");
    }
    else if (solution == MCFSolver::UNBOUNDED){
        mexPrintf("MCF solution is unbounded!\n");
    }
    else{
        //mexPrintf("MCF solution is optimal!\n");
        totalCost = solver.totalCost();
        
        for (int i = 0; i < n; i++){
            for (int j = 0; j < k; j++){
                dcFlow[j * n + i] = solver.flow(dcArcs[i][j]);
            }
        }
        
        //for (int i = 0; i < n; i++){
        //    sdFlow[i] = solver.flow(sdArcs[i]);
        //}
        //for (int j = 0; j < k; j++){
        //    ctFlow[j] = solver.flow(ctArcs[j]);
        //}
        //for (int j = 0; j < k; j++){
        //    cttFlow[j] = solver.flow(cttArcs[j]);
        //}
        //tttFlow = solver.flow(tttArcs);
    }
    
    // output parameters
    enum{
        DCFLOW_OUT = 0,
        TOTALCOST_OUT,
        //SDFLOW_OUT,
        //CTFLOW_OUT,
        //CTTFLOW_OUT,
        //TTTFLOW_OUT,
    };
    
    plhs[DCFLOW_OUT] = mxCreateDoubleMatrix(n, k, mxREAL);
    double *dcFlow_out = mxGetPr(plhs[DCFLOW_OUT]);
    memcpy(dcFlow_out, dcFlow, n * k * sizeof(double));
    
    plhs[TOTALCOST_OUT] = mxCreateDoubleMatrix(1, 1, mxREAL);
    *mxGetPr(plhs[TOTALCOST_OUT]) = totalCost;
    
    //plhs[SDFLOW_OUT] = mxCreateDoubleMatrix(n, 1, mxREAL);
    //double *sdFlow_out = mxGetPr(plhs[SDFLOW_OUT]);
    //memcpy(sdFlow_out, sdFlow, n * sizeof(double));
    
    //plhs[CTFLOW_OUT] = mxCreateDoubleMatrix(k, 1, mxREAL);
    //double *ctFlow_out = mxGetPr(plhs[CTFLOW_OUT]);
    //memcpy(ctFlow_out, ctFlow, k * sizeof(double));
    
    //plhs[CTTFLOW_OUT] = mxCreateDoubleMatrix(k, 1, mxREAL);
    //double *cttFlow_out = mxGetPr(plhs[CTTFLOW_OUT]);
    //memcpy(cttFlow_out, cttFlow, k * sizeof(double));
    
    //plhs[TTTFLOW_OUT] = mxCreateDoubleMatrix(1, 1, mxREAL);
    //*mxGetPr(plhs[TTTFLOW_OUT]) = tttFlow;
    
    // deallocate memory
    delete [] dcFlow;
    //delete [] sdFlow;
    //delete [] ctFlow;
    //delete [] cttFlow;
}

