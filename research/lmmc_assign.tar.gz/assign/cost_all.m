function costs = cost_all(scores, deltas)

[ni, kc] = size(scores);
scores = double(scores);

if nargin == 1
    deltas = ones(kc, 1);
end

% clustering closts
costs = zeros(ni, kc);
for k = 1:kc
    xi = scores + deltas(k) - repmat(scores(:, k), [1, kc]);
    xi(:, k) = 0;
    xi(xi < 0) = 0;
    costs(:, k) = sum(xi, 2);
end
