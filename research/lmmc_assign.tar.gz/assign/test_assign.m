% A demo code for clustering assignment
% 
% by Guang-Tong Zhou (zhouguangtong@gmail.com)
% 
% Reference:
% G.-T. Zhou, T. Lan, A. Vahdat, and G. Mori.
% Latent Maximum Margin Clustering.
% Neural Information Processing Systems (NIPS), 2013.
% 
% We have two solvers:
% The first ILP solver is described in our NIPS paper.
% The second MCF solver uses min-cost flow (faster and recommended).
% 

n = 2379; % the number of videos in TRECVID MED 11
k = 15; % the number of clusters in TRECVID MED 11

% randomly generate scores
% should be the compatibility scores obtained from learning
scores = rand(n, k);

% ILP solver (using glpk)
% 
% dowmload glpkmex from http://glpkmex.sourceforge.net/
% compile and add glpkmex to path
% we have included the compiled 'glpkcc' for 64-bit linux
% 

disp('ILP solver:');
tic;
lsize = 0.9 * (n / k);
usize = 1.1 * (n / k);
labels_lpa = assign_ilp(scores, lsize, usize);
toc

% MCF solver (using lemon)
% 
% dowmload lemon from http://lemon.cs.elte.hu/trac/lemon
% compile the mex file: make -f make_assgin_mcf
% we have included the compiled 'assign_mcf' for 64-bit linux
% 

options.mcfSolver = 1;
options.fRate = 1;
options.lsizeRate = 0.9;
options.usizeRate = 1.1;

disp('MCF solver:');
tic;
costs = cost_all(scores);
[dcFlow, totalCost] = assign_mcf(costs, options);
[mx, labels_mcf] = max(dcFlow, [], 2);
labels_mcf(mx == 0) = 0;
toc

% compare the results
if sum(labels_mcf == labels_lpa) == n
    disp('ILP and MCF produce the same assignment!');
else
    disp('ILP and MCF produce different assignments!');
end

